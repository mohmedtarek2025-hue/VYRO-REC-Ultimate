package com.vyro.rec

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun text(value: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); if (bold) setTypeface(null, Typeface.BOLD)
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(7, 8, 12); window.navigationBarColor = Color.rgb(7, 8, 12)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(26), dp(28), dp(26), dp(28)); setBackgroundColor(Color.rgb(7,8,12)) }
        root.addView(text("VYRO REC", 34f, Color.WHITE, true))
        root.addView(text("ULTIMATE SCREEN STUDIO", 12f, Color.rgb(255,65,78), true))
        val gap = android.view.View(this); root.addView(gap, LinearLayout.LayoutParams(1, dp(34)))
        root.addView(text("تسجيل الشاشة. صوتك. لحظاتك.", 20f, Color.WHITE, true))
        val desc = text("استوديو تسجيل احترافي قيد التطوير. ستظهر هنا أدوات التسجيل بعد اكتمال محرك الالتقاط واختباره.", 14f, Color.LTGRAY)
        desc.gravity = Gravity.CENTER; desc.setPadding(0, dp(14), 0, dp(24)); root.addView(desc)
        root.addView(text("Crafted with Innovation", 13f, Color.rgb(211,169,83), true))
        root.addView(text("Developed by Mohamed Tarek", 14f, Color.rgb(211,169,83), true))
        root.addView(text("An independent product by Mohamed Tarek", 11f, Color.GRAY))
        setContentView(root)
    }
}
