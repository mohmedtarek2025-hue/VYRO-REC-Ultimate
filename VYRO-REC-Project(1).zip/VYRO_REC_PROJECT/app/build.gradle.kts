plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "com.vyro.rec"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.vyro.rec"
        minSdk = 29
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0-dev"
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildTypes { release { isMinifyEnabled = false } }
}
