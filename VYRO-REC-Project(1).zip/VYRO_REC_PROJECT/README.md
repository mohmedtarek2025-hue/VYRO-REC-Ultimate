# VYRO REC — project foundation

**Crafted with Innovation — Developed by Mohamed Tarek**  
**An independent product by Mohamed Tarek**

This is a clean Android Studio / GitHub Actions project foundation with the supplied VYRO REC launcher icon and developer attribution in the app's opening screen.

## Important status
This is NOT a finished screen recorder and is NOT ready for sale or Google Play publication. The current app is a branded foundation only. The recording engine, single-file MP4 audio/video muxing, Smart Audio Ducking, floating controls, face camera, editor, device capability detection, media library, and release QA still need implementation and testing. Do not list those as working features yet.

## Build
- Android Gradle Plugin 8.10.1
- Gradle 8.11.1
- Java 17
- minSdk 29 (Android 10)
- targetSdk 35
- applicationId `com.vyro.rec`

GitHub Actions builds a **debug APK for testing only**. It does not produce a signed store-ready release. The app icon is installed as Android launcher resources automatically by the build; keep the `app/src/main/res/mipmap-*` and `mipmap-anydpi-v26` files.
